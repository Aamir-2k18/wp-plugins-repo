<?php
// Direct access security
wp_die();