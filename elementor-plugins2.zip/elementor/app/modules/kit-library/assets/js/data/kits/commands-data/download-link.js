export class DownloadLink extends $e.modules.CommandData {
	static getEndpointFormat() {
		return 'kits/download-link/{id}';
	}
}
