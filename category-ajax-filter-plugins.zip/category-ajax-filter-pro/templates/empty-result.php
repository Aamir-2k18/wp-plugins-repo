<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
echo "<div class='error-of-empty-result error-caf'>" . esc_html($caf_empty_res) . "</div>";