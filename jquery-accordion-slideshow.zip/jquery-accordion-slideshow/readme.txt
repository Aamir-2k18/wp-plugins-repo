=== Jquery accordion slideshow ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/
Author URI: http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/
Plugin URI: http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/
Tags:  jquery, accordion, slideshow, slider
Requires at least: 3.2
Tested up to: 4.1
Stable tag: 6.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This is slideshow plugin for wp with accordion effect using famous Jquery js. Using this we can easily create horizontal accordion slideshow.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/](http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/)

Live demo : [Live demo](http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/)		 	
More information : [More information](http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/)			 		
User comments and suggestion : [User comments and suggestion](http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/)			 	
About author : [About author](http://www.gopiplus.com/work/) 	

Jquery Accordion Slideshow is another slideshow plugin for Word Press with accordion effect using famous JQuery JavaScript. Using this word press plugin we can easily create horizontal accordion slideshow. We can customize the timeout between the slides and trigger option.

What is Accordion? Accordion is a web control that allows you to provide multiple panes and display them one at a time. It is like having several collapsible panels where only one can be expanded at a time. See the plugin Live Demo below.

**Facility of this plugin**

* Option to set timeout between slide.
* Pause on hover.
* Option to set With/Height.

How to add gallery in the Posts or Pages? Copy and paste the given short code into pages or posts.

== Installation ==

[Installation instruction and configuration](http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/)

== Frequently Asked Questions ==

Q1. How to upload my image?

Q2. I can't see my images in the front end?

Q3. Where is this plugin admin option?

== Screenshots ==

1. Front end. http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/

2. Admin page. http://www.gopiplus.com/work/2011/12/21/jquery-accordion-slideshow-wordpress-plugin/

== Upgrade Notice ==

= 1.0 =

First version

= 2.0 =

Tested UpTo 3.4	

= 3.0 =

JavaScript loaded by using the wp_enqueue_scripts hook (instead of the init hook)
Slight change in the short code, Please find the new short code for your gallery

= 4.0 =

New demo link, www.gopiplus.com

= 5.0 =

Tested up to: 3.4.2

= 5.1 =

Tested up to 3.5
Avoid registering the alternate jQuery. No jQuery conflict.

= 6.0 =

Tested up to 3.6
Added few security features.
New admin layout.

= 6.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (jquery-accordion.po) available in the languages folder.

= 6.2 =

1. Tested up to 3.9
2. Added little security feature.

= 6.3 =

1. Tested up to 4.0

= 6.4 =

1. Tested up to 4.1

== Changelog ==

= 1.0 =

First version

= 2.0 =

Tested up to 3.4	

= 3.0 =

JavaScript loaded by using the wp_enqueue_scripts hook (instead of the init hook)
Slight change in the short code, Please find the new short code for your gallery

= 4.0 =

New demo link, www.gopiplus.com

= 5.0 =

Tested up to 3.4.2

= 5.1 =

Tested up to 3.5
Avoid registering the alternate jQuery. No jQuery conflict.

= 6.0 =

Tested up to 3.6
Added few security features.
New admin layout.

= 6.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (jquery-accordion.po) available in the languages folder.

= 6.2 =

1. Tested up to 3.9
2. Added little security feature.

= 6.3 =

1. Tested up to 4.0

= 6.4 =

1. Tested up to 4.1