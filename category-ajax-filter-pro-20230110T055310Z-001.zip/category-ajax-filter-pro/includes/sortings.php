<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly
}
?>
<!--<div class='caf-manage-sorting-front'>
<ul>
  <li class="active">Deafult</li>
  <li>Latest Posts</li>
  <li>Older Posts</li>
 </ul>
 <label>Sort :
 <select class="caf-sort-front">
 <option value="0">Default</option>
 <option value="asc">Latest</option>
 <option value="desc">Older</option>
 </select></label>
</div>-->

