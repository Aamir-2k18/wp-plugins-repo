<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
if ($caf_pagi_type == 'load-more') {
    $caf_load_more_text = 'Load More';
    //echo $filter_id;
    if (get_post_meta($filter_id, 'caf_load_more_text')) {
        $caf_load_more_text = get_post_meta($filter_id, 'caf_load_more_text', true);
    }
    if (!$query) {
        return;
    }

    $total = $query->max_num_pages;
    $current = max(1, $paged);
    $next = $current + 1;
    if ($query->max_num_pages > 1): ?>
       <div class='load-more-container'><button id="tp-load-more" class="tp_load_more <?php echo esc_attr($caf_post_layout); ?>" data-current="<?php echo esc_attr($current); ?>" data-total="<?php echo esc_attr($total); ?>" data-next="<?php echo esc_attr($next); ?>"><?php echo esc_html($caf_load_more_text); ?></button></div>
    <?php endif;
}
?>