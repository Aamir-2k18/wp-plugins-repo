<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
if($caf_post_layout=="post-layout11") {
echo "</div>";
}
else {
    echo "</article>";
}