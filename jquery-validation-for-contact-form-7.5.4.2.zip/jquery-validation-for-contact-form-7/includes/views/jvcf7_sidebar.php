<div class="dcsidebar">
    <div class="sidebar-head">        
        WP Armour - Anti Spam Plugin
    </div>

    <div class="sidebar-content">        
        <p>Do you know <strong>WP Armour - Anti Spam</strong> blocks spam for Contact Form 7, comments and registration. No need for Captcha or puzzle. </p>

                <p>Great addition to jQuery Validation and Contact Form 7. Just install and activate to block spams. No additional settings required.</p>

                <p align="right"><br/><a href="<?php echo admin_url('plugin-install.php?s=WP+Armour&tab=search'); ?>" target="_blank" class="button-primary">Install Now ( Free )</a><p>
    </div>
</div>

<div class="dcsidebar">
    <div class="sidebar-head">        
        Plugins You May Like
    </div>

    <div class="sidebar-content">        
        <ul>
            <li><a href="http://wordpress.org/extend/plugins/use-any-font/" target="_blank">Use Any Font</a></li>
            <li><a href="http://goo.gl/3XDDzi" target="_blank">WP Masonry Layout</a></li>
            <li><a href="http://wordpress.org/extend/plugins/any-mobile-theme-switcher/" target="_blank">Any Mobile Theme Switcher</a></li>
            <li><a href="http://wordpress.org/extend/plugins/add-tags-and-category-to-page/" target="_blank">Add Tags And Category To Page</a></li>
            <li><a href="http://wordpress.org/extend/plugins/block-specific-plugin-updates/" target="_blank">Block Specific Plugin Updates</a></li>
            <li><a href="http://wordpress.org/extend/plugins/featured-image-in-rss-feed/" target="_blank">Featured Image In RSS Feed</a></li>
            <li><a href="http://wordpress.org/extend/plugins/remove-admin-bar-for-client/" target="_blank">Remove Admin Bar</a></li>
            <li><a href="http://wordpress.org/extend/plugins/html-in-category-and-pages/" target="_blank">.html in category and page url</a></li>
        </ul>
    </div>
</div>