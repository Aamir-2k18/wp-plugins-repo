# Ajax-File-UploadV1
 add_file_upload_to_form(
      add_after, //to add after what?
      container_css_class, //the file upload parent div
      upload_class, // apply class to input file upload
      image_preview_class, // apply class to preview img tag parent
      preview_image_class// apply class to preview img tag 
 );
