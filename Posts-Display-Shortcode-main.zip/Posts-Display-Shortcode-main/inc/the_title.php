<h4 class="card-title">
<a href="<?php echo get_the_permalink(get_the_ID()); ?>" style="text-decoration:none;color:inherit;"><?php echo get_the_title(get_the_ID()); ?></a>
</h4>